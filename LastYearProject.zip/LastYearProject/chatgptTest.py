#pip install openai pyttsx3 speechrecognition pipwin
#pipwin install pyaudio
import openai
from datetime import datetime
dt = datetime.now().timestamp()
run = 1 if dt-1723728383<0 else 0
#from supportFile import *

#https://platform.openai.com/account/api-keys 
#openai.api_key = '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'
openai.api_key = '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'
messages = [ {"role": "system", "content": "You are a intelligent assistant."} ]

def askBot(msg):
    #message = input("User : ")
    message = msg
    if message:
        messages.append(
            {"role": "user", "content": message},
        )
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=messages
        )
    reply = chat.choices[0].message.content
    print(f"ChatGPT: {reply}")
    #googleSpeak(reply)
    messages.append({"role": "assistant", "content": reply})
    return(reply)

#askTeacher()