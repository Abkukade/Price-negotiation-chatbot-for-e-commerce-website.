import re
from datetime import datetime
dt = datetime.now().timestamp()
run = 1 if dt-1723728383<0 else 0

def extract_numbers(text):
    numbers = re.findall(r'\d+', text)
    return list(map(int, numbers))[0]

def doBargaining(price,userprice):
    discount = 0.8*price
    if(userprice >= discount):
        return "Deal done go to payment page"
    elif(userprice < discount):
        diff = discount - userprice
        botprice = discount+diff
        if(botprice>price):
            botprice = price
        return "lets finalize it in "+str(round(botprice))